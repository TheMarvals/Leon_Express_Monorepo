const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const AdditionalCost = sequelize.define('AdditionalCost', {
  cost_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  cost_name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  cost_value: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  applies_to: {
    type: DataTypes.ENUM('CLIENT', 'REPARTIDOR', 'AMBOS'),
    allowNull: false
  }
}, {
  tableName: 'additional_costs',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = AdditionalCost;