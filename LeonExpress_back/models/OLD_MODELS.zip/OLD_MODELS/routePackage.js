const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const RoutePackage = sequelize.define('RoutePackage', {
  route_package_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  route_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  }
}, {
  tableName: 'route_packages',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = RoutePackage;