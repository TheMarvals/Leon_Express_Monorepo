const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const PackageCost = sequelize.define('PackageCost', {
  package_cost_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  cost_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  applied_value: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  }
}, {
  tableName: 'package_costs',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = PackageCost;