const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const { v4: uuidv4 } = require('uuid');

const Vehicle = sequelize.define('Vehicle', {
  vehicle_id: {
    type: DataTypes.STRING(36),
    defaultValue: () => uuidv4(),
    primaryKey: true,
  },
  license_plate: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true,
  },
  type_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
  }
}, {
  tableName: 'vehicles',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = Vehicle;