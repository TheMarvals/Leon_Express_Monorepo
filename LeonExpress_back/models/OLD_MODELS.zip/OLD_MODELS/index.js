const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Role = require('./role');
const Client = require('./client');
const ClientPricing = require('./clientPricing');
const User = require('./user');
const Package = require('./package');
const Route = require('./route');
const RoutePackage = require('./routePackage');
const Delivery = require('./delivery');
const Pickup = require('./pickup');
const AuditLog = require('./auditLog');
const PackageCost = require('./packageCost');

// --- NEW IMPORTS ---
const VehicleType = require('./vehicleType'); // Asegúrate de tener vehicleType.js
const Vehicle = require('./vehicle');         // Asegúrate de tener vehicle.js
// --- END NEW IMPORTS ---

// =================================================================
// --- DEFINICIÓN DE ASOCIACIONES ---
// A continuación se definen todas las relaciones entre las tablas
// basadas en las claves foráneas (FOREIGN KEY) de tu schema.sql.
// =================================================================

// User <-> Role (Uno a Muchos)
Role.hasMany(User, { foreignKey: 'role_id', as: 'users' });
User.belongsTo(Role, { foreignKey: 'role_id', as: 'role' });

// Client <-> Package (Uno a Muchos)
Client.hasMany(Package, { foreignKey: 'client_id' });
Package.belongsTo(Client, { foreignKey: 'client_id' });

// User <-> Route (Uno a Muchos)
User.hasMany(Route, { foreignKey: 'user_id' });
Route.belongsTo(User, { foreignKey: 'user_id' });

// User <-> Pickup (Uno a Muchos)
User.hasMany(Pickup, { foreignKey: 'user_id' });
Pickup.belongsTo(User, { foreignKey: 'user_id' });

// User <-> AuditLog (Uno a Muchos)
User.hasMany(AuditLog, { foreignKey: 'user_id' });
AuditLog.belongsTo(User, { foreignKey: 'user_id' });

// Package <-> Delivery (Uno a Uno)
Package.hasOne(Delivery, { foreignKey: 'package_id' });
Delivery.belongsTo(Package, { foreignKey: 'package_id' });

// Package <-> Pickup (Uno a Muchos)
Pickup.hasMany(Package, { foreignKey: 'pickup_id', as: 'packages' });
Package.belongsTo(Pickup, { foreignKey: 'pickup_id', as: 'pickup' });

// Route <-> Package (Muchos a Muchos)
Route.belongsToMany(Package, {
  through: RoutePackage,
  foreignKey: 'route_id',
  otherKey: 'package_id'
});
Package.belongsToMany(Route, {
  through: RoutePackage,
  foreignKey: 'package_id',
  otherKey: 'route_id'
});

// =================================================================
// --- NUEVAS ASOCIACIONES PARA VEHÍCULOS Y TIPOS DE VEHÍCULO ---
// =================================================================

// User <-> Vehicle (Uno a Uno)
User.hasOne(Vehicle, { foreignKey: 'user_id', as: 'vehicle' });
Vehicle.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// Vehicle <-> VehicleType (Uno a Muchos)
VehicleType.hasMany(Vehicle, { foreignKey: 'type_id', as: 'vehicles' });
Vehicle.belongsTo(VehicleType, { foreignKey: 'type_id', as: 'vehicleType' });

// Delivery <-> Vehicle (Uno a Muchos)
Vehicle.hasMany(Delivery, { foreignKey: 'vehicle_id', as: 'deliveries' });
Delivery.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });

// Pickup <-> Vehicle (Uno a Muchos)
Vehicle.hasMany(Pickup, { foreignKey: 'vehicle_id', as: 'pickups' });
Pickup.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });

// Client <-> ClientPricing (Uno a Muchos)
Client.hasMany(ClientPricing, { foreignKey: 'client_id', as: 'pricings'});
ClientPricing.belongsTo(Client, { foreignKey: 'client_id', as: 'client'});

Package.hasMany(PackageCost, { foreignKey: 'package_id', as: 'costs' }); // Add PackageCost association
PackageCost.belongsTo(Package, { foreignKey: 'package_id' });

// Route <-> Vehicle (Uno a Muchos) - Si agregaste vehicle_id a routes
// Vehicle.hasMany(Route, { foreignKey: 'vehicle_id', as: 'routes' });
// Route.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });

// =================================================================
// --- EXPORTACIÓN DE MODELOS ---
// =================================================================

module.exports = {
  Role,
  Client,
  ClientPricing,
  User,
  Package,
  Route,
  RoutePackage,
  Delivery,
  Pickup,
  AuditLog,
  VehicleType,
  Vehicle,
  PackageCost,
  sequelize
};