const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Route = sequelize.define('Route', {
  route_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  start_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  end_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('PENDIENTE', 'EN_PROGRESO', 'FINALIZADA'),
    allowNull: false,
    defaultValue: 'PENDIENTE'
  }
}, {
  tableName: 'routes',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

module.exports = Route;