const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Delivery = sequelize.define('Delivery', {
  delivery_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  vehicle_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  receiver_name: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  receiver_rut: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  observation: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  photo_urls: {
    type: DataTypes.JSON,
    allowNull: true
  },
  gps_latitude: {
    type: DataTypes.DECIMAL(10, 8),
    allowNull: true
  },
  gps_longitude: {
    type: DataTypes.DECIMAL(11, 8),
    allowNull: true
  },
  delivered_at: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'deliveries',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = Delivery;