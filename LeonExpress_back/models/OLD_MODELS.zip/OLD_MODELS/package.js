const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Client = require('./client');
const Pickup = require('./pickup');

const Package = sequelize.define('Package', {
  package_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: () => require('uuid').v4()
  },
  tracking_code: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: Client, key: 'client_id' }
  },
  pickup_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: Pickup, key: 'pickup_id' }
  },
  status: {
    type: DataTypes.ENUM('RECIBIDO', 'ASIGNADO', 'EN_RUTA', 'ENTREGADO', 'NO_HAY_NADIE', 'REPROGRAMADO'),
    defaultValue: 'RECIBIDO'
  },
  received_date: { type: DataTypes.DATE, allowNull: false },
  assigned_date: { type: DataTypes.DATE },
  delivery_date: { type: DataTypes.DATE },
  address: { type: DataTypes.TEXT }, // Nuevo campo para la dirección
  recipient: { type: DataTypes.STRING(100) }, // Destinatario
  phone: { type: DataTypes.STRING(20) } // Teléfono del destinatario
}, {
  tableName: 'packages',
  timestamps: true
});

module.exports = Package;