const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const { v4: uuidv4 } = require('uuid');

const VehicleType = sequelize.define('VehicleType', {
  type_id: {
    type: DataTypes.STRING(36),
    defaultValue: () => uuidv4(),
    primaryKey: true,
  },
  type_name: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true,
  },
  delivery_cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    comment: 'Costo que se paga al repartidor',
  }
}, {
  tableName: 'vehicle_types',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = VehicleType;