const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ClientPricing = sequelize.define('ClientPricing', {
  price_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  base_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  description: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  valid_from: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  valid_to: {
    type: DataTypes.DATEONLY,
    allowNull: true
  }
}, {
  tableName: 'client_pricing',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false
});

module.exports = ClientPricing;