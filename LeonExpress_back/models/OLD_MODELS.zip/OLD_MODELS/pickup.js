const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');

const Pickup = sequelize.define('Pickup', {
  pickup_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    defaultValue: () => require('uuid').v4()
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: User, key: 'user_id' }
  },
  pickup_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('PENDIENTE', 'COMPLETADO'),
    defaultValue: 'PENDIENTE'
  }
}, {
  tableName: 'pickups',
  timestamps: true
});

module.exports = Pickup;