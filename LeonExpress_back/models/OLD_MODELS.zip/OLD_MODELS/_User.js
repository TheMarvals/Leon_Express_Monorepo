// models/user.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Role = require('./role');

const User = sequelize.define('User', {
    user_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    username: {
        type: DataTypes.STRING(50),
        unique: true,
        allowNull: false
    },
    password_hash: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Role,
            key: 'role_id'
        }
    },
    full_name: DataTypes.STRING(100),
    email: DataTypes.STRING(100),
    phone: DataTypes.STRING(20)
}, {
    tableName: 'users',
    timestamps: true
});

User.belongsTo(Role, { foreignKey: 'role_id' });
module.exports = User;