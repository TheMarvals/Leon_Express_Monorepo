const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DriverPayout = sequelize.define('DriverPayout', {
  payout_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    comment: 'El ID del driver que recibe el pago'
  },
  payout_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  total_amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00
  },
  status: {
    type: DataTypes.ENUM('PENDIENTE', 'PAGADO', 'CANCELADO'),
    allowNull: false,
    defaultValue: 'PENDIENTE'
  },
  paid_at: {
    type: DataTypes.DATE
  },
  notes: {
    type: DataTypes.TEXT
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'driver_payouts',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  comment: 'Gestiona los pagos a conductores'
});

module.exports = DriverPayout;