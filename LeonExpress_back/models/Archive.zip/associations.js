const Role = require('./roles');
const Warehouse = require('./warehouses');
const User = require('./users');
const Client = require('./clients');
const VehicleType = require('./vehicle_types');
const Vehicle = require('./vehicles');
const ClientPricing = require('./client_pricing');
const Pickup = require('./pickups');
const Package = require('./packages');
const Route = require('./routes');
const RoutePackage = require('./route_packages');
const Delivery = require('./deliveries');
const DeliveryPhoto = require('./delivery_photos');
const AuditLog = require('./audit_log');
const Invoice = require('./invoices');
const InvoiceItem = require('./invoice_items');
const Payment = require('./payments');
const DriverPayout = require('./driver_payouts');
const PayoutItem = require('./payout_items');
const FullPackageJourney = require('./FullPackageJourney'); 
const ClientBillingSummary = require('./ClientBillingSummary'); 
const DriverEarningsSummary = require('./DriverEarningsSummary'); 

// 1. Relaciones para Role
Role.hasMany(User, { foreignKey: 'role_id', as: 'users' });
User.belongsTo(Role, { foreignKey: 'role_id', as: 'role' });

// 2. Relaciones para Warehouse
Warehouse.hasMany(User, { foreignKey: 'warehouse_id', as: 'users' });
User.belongsTo(Warehouse, { foreignKey: 'warehouse_id', as: 'warehouse' });
Warehouse.hasMany(Route, { foreignKey: 'warehouse_id', as: 'routes' });
Route.belongsTo(Warehouse, { foreignKey: 'warehouse_id', as: 'warehouse' });

// 3. Relaciones para User
User.hasMany(Vehicle, { foreignKey: 'user_id', as: 'vehicles' });
Vehicle.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(Pickup, { foreignKey: 'user_id', as: 'pickups' });
Pickup.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(Route, { foreignKey: 'user_id', as: 'routes' });
Route.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(Delivery, { foreignKey: 'user_id', as: 'deliveries' });
Delivery.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(DriverPayout, { foreignKey: 'user_id', as: 'driver_payouts' });
DriverPayout.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(AuditLog, { foreignKey: 'user_id', as: 'audit_logs' });
AuditLog.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// 4. Relaciones para Client (con alias corregido)
Client.hasMany(ClientPricing, { 
  foreignKey: 'client_id', 
  as: 'client_pricings'  // Alias en plural para consistencia
});
ClientPricing.belongsTo(Client, { 
  foreignKey: 'client_id', 
  as: 'client' 
});
Client.hasMany(Pickup, { foreignKey: 'client_id', as: 'pickups' });
Pickup.belongsTo(Client, { foreignKey: 'client_id', as: 'client' });
Client.hasMany(Package, { foreignKey: 'client_id', as: 'packages' });
Package.belongsTo(Client, { foreignKey: 'client_id', as: 'client' });
Client.hasMany(Invoice, { foreignKey: 'client_id', as: 'invoices' });
Invoice.belongsTo(Client, { foreignKey: 'client_id', as: 'client' });
Client.hasOne(ClientBillingSummary, { 
  foreignKey: 'client_id', 
  as: 'billing_summary' 
});

// 5. Relaciones para VehicleType
VehicleType.hasMany(Vehicle, { foreignKey: 'type_id', as: 'vehicles' });
Vehicle.belongsTo(VehicleType, { foreignKey: 'type_id', as: 'vehicle_type' });

// 6. Relaciones para Vehicle
Vehicle.hasMany(Route, { foreignKey: 'vehicle_id', as: 'routes' });
Route.belongsTo(Vehicle, { foreignKey: 'vehicle_id', as: 'vehicle' });

// 7. Relaciones para Pickup
Pickup.hasMany(Package, { foreignKey: 'pickup_id', as: 'packages' });
Package.belongsTo(Pickup, { foreignKey: 'pickup_id', as: 'pickup' });
Pickup.hasMany(PayoutItem, { foreignKey: 'pickup_id', as: 'payout_items' });
PayoutItem.belongsTo(Pickup, { foreignKey: 'pickup_id', as: 'pickup' });

// 8. Relaciones para Package
Package.hasMany(RoutePackage, { foreignKey: 'package_id', as: 'route_packages' });
RoutePackage.belongsTo(Package, { foreignKey: 'package_id', as: 'package' });
Package.hasMany(Delivery, { foreignKey: 'package_id', as: 'deliveries' });
Delivery.belongsTo(Package, { foreignKey: 'package_id', as: 'package' });
Package.hasMany(InvoiceItem, { foreignKey: 'package_id', as: 'invoice_items' });
InvoiceItem.belongsTo(Package, { foreignKey: 'package_id', as: 'package' });
Package.hasMany(PayoutItem, { foreignKey: 'package_id', as: 'payout_items' });
PayoutItem.belongsTo(Package, { foreignKey: 'package_id', as: 'package' });
Package.hasOne(FullPackageJourney, { 
  foreignKey: 'package_id', 
  as: 'journey' 
});

// 9. Relaciones para Route
Route.hasMany(RoutePackage, { foreignKey: 'route_id', as: 'route_packages' });
RoutePackage.belongsTo(Route, { foreignKey: 'route_id', as: 'route' });

// 10. Relaciones para RoutePackage
RoutePackage.hasMany(Delivery, { 
  foreignKey: 'route_package_id', 
  as: 'deliveries' 
});
Delivery.belongsTo(RoutePackage, { 
  foreignKey: 'route_package_id', 
  as: 'route_package' 
});

// 11. Relaciones para Delivery
Delivery.hasMany(DeliveryPhoto, { 
  foreignKey: 'delivery_id', 
  as: 'delivery_photos' 
});
DeliveryPhoto.belongsTo(Delivery, { 
  foreignKey: 'delivery_id', 
  as: 'delivery' 
});

// 12. Relaciones para Invoice
Invoice.hasMany(InvoiceItem, { 
  foreignKey: 'invoice_id', 
  as: 'invoice_items' 
});
InvoiceItem.belongsTo(Invoice, { 
  foreignKey: 'invoice_id', 
  as: 'invoice' 
});
Invoice.hasMany(Payment, { 
  foreignKey: 'invoice_id', 
  as: 'payments' 
});
Payment.belongsTo(Invoice, { 
  foreignKey: 'invoice_id', 
  as: 'invoice' 
});

// 13. Relaciones para DriverPayout
DriverPayout.hasMany(PayoutItem, { 
  foreignKey: 'payout_id', 
  as: 'payout_items' 
});
PayoutItem.belongsTo(DriverPayout, { 
  foreignKey: 'payout_id', 
  as: 'driver_payout' 
});

// 14. Relaciones para resúmenes
User.hasOne(DriverEarningsSummary, { 
  foreignKey: 'user_id', 
  as: 'earnings_summary' 
});

module.exports = {
  Role,
  Warehouse,
  User,
  Client,
  VehicleType,
  Vehicle,
  ClientPricing,
  Pickup,
  Package,
  Route,
  RoutePackage,
  Delivery,
  DeliveryPhoto,
  AuditLog,
  Invoice,
  InvoiceItem,
  Payment,
  DriverPayout,
  PayoutItem,
  FullPackageJourney,
  ClientBillingSummary,
  DriverEarningsSummary
};