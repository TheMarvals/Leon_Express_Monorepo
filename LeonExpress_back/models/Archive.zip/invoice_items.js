const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const InvoiceItem = sequelize.define('InvoiceItem', {
  invoice_item_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  invoice_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  item_description: {
    type: DataTypes.STRING(255),
    allowNull: false,
    comment: 'Ej. "Envío TRK123456789"'
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    comment: 'El precio del paquete al cliente'
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'invoice_items',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  comment: 'Registra los ítems de las facturas'
});

module.exports = InvoiceItem;