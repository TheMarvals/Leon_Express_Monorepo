const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Package = sequelize.define('Package', {
  package_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  tracking_code: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true,
  },
  pickup_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'pickups', key: 'pickup_id' },
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'clients', key: 'client_id' },
  },
  status: {
    type: DataTypes.ENUM(
      'RECOLECTADO_EN_ORIGEN',
      'RECIBIDO_EN_ALMACEN',
      'ASIGNADO_A_RUTA',
      'EN_RUTA_ENTREGA',
      'ENTREGADO',
      'INCIDENCIA_ENTREGA',
      'REPROGRAMADO',
      'DEVUELTO_ALMACEN'
    ),
    defaultValue: 'RECOLECTADO_EN_ORIGEN',
    allowNull: false,
  },
  client_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  delivery_cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  scanned_at_origin_datetime: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  received_at_warehouse_datetime: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  assigned_to_route_datetime: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  delivered_datetime: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  destination_address: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  recipient_name: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  recipient_phone: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
}, {
  tableName: 'packages',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

module.exports = Package;