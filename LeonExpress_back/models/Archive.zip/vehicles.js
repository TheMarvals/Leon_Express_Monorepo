const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Vehicle = sequelize.define('Vehicle', {
  vehicle_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: true,
    references: { model: 'users', key: 'user_id' },
  },
  type_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'vehicle_types', key: 'type_id' },
  },
  license_plate: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
}, {
  tableName: 'vehicles',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

module.exports = Vehicle;