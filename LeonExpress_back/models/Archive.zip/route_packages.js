const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Modelo para route_packages
const RoutePackage = sequelize.define('RoutePackage', {
  route_package_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  route_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'routes', key: 'route_id' },
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'packages', key: 'package_id' },
  },
  sequence_in_route: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'route_packages',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  indexes: [
    { unique: true, fields: ['route_id', 'package_id'] },
  ],
});

module.exports = RoutePackage;