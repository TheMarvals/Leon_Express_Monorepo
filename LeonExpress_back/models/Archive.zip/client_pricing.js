const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ClientPricing = sequelize.define('ClientPricing', {
  pricing_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'clients', key: 'client_id' },
  },
  base_price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  valid_from: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  valid_to: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
}, {
  tableName: 'client_pricing',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  indexes: [
    { unique: true, fields: ['client_id', 'valid_from'] },
  ],
});

module.exports = ClientPricing;
