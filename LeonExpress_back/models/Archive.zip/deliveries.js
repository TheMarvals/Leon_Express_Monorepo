const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Modelo para deliveries
const Delivery = sequelize.define('Delivery', {
  delivery_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  package_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'packages', key: 'package_id' },
  },
  route_package_id: {
    type: DataTypes.STRING(36),
    allowNull: true,
    references: { model: 'route_packages', key: 'route_package_id' },
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'users', key: 'user_id' },
  },
  status_at_delivery: {
    type: DataTypes.ENUM(
      'ENTREGADO',
      'NO_HAY_NADIE',
      'DIRECCION_INCORRECTA',
      'RECHAZADO_POR_CLIENTE',
      'REPROGRAMADO_POR_CLIENTE',
      'OTRA_INCIDENCIA'
    ),
    allowNull: false,
  },
  receiver_name: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  receiver_rut: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  observation: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  gps_latitude: {
    type: DataTypes.DECIMAL(10, 8),
    allowNull: true,
  },
  gps_longitude: {
    type: DataTypes.DECIMAL(11, 8),
    allowNull: true,
  },
  attempted_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  payment_type: {
    type: DataTypes.ENUM('PAGADO_ONLINE', 'EFECTIVO', 'NO_APLICA'),
    allowNull: false,
    defaultValue: 'NO_APLICA',
  },
  collected_amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
}, {
  tableName: 'deliveries',
  timestamps: true,
  createdAt: 'attempted_at',
  updatedAt: false,
});


module.exports = Delivery;