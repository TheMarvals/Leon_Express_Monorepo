const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Pickup = sequelize.define('Pickup', {
  pickup_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'users', key: 'user_id' },
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'clients', key: 'client_id' },
  },
  pickup_scheduled_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM(
      'ASIGNADO_A_RECOLECTOR',
      'EN_PROCESO_RECOLECCION',
      'RECOLECCION_FINALIZADA_DRIVER',
      'ENTREGADO_EN_ALMACEN',
      'VERIFICADO_EN_ALMACEN',
      'CANCELADO'
    ),
    defaultValue: 'ASIGNADO_A_RECOLECTOR',
    allowNull: false,
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  pickup_cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00,
  },
  pickup_completed_by_driver_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  arrived_at_warehouse_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  verified_at_warehouse_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
}, {
  tableName: 'pickups',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});


module.exports = Pickup;