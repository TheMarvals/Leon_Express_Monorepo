const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Payment = sequelize.define('Payment', {
  payment_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  invoice_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  payment_date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  payment_method: {
    type: DataTypes.STRING(50),
    comment: 'Ej. "Transferencia", "Efectivo", "Tarjeta"'
  },
  transaction_reference: {
    type: DataTypes.STRING(100),
    comment: 'Número de transacción, ID de depósito, etc.'
  },
  notes: {
    type: DataTypes.TEXT
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'payments',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  comment: 'Registra los pagos recibidos de clientes'
});

module.exports = Payment;