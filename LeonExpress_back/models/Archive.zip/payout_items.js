const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const PayoutItem = sequelize.define('PayoutItem', {
  payout_item_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  payout_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  package_id: {
    type: DataTypes.STRING(36),
    comment: 'Paquete entregado por el que se paga'
  },
  pickup_id: {
    type: DataTypes.STRING(36),
    comment: 'Recolección realizada por la que se paga'
  },
  item_description: {
    type: DataTypes.STRING(255),
    allowNull: false,
    comment: 'Ej. "Entrega TRK123456789", "Recolección Cliente X"'
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    comment: 'Costo pagado al driver por este servicio'
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'payout_items',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  comment: 'Registra los ítems de pagos a conductores'
});

module.exports = PayoutItem;