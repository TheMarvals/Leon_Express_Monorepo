const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const VehicleType = sequelize.define('VehicleType', {
  type_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  type_name: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true,
  },
  base_delivery_cost: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'vehicle_types',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = VehicleType;