const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Route = sequelize.define('Route', {
  route_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'users', key: 'user_id' },
  },
  vehicle_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'vehicles', key: 'vehicle_id' },
  },
  warehouse_id: {
    type: DataTypes.STRING(36),
    allowNull: false,
    references: { model: 'warehouses', key: 'warehouse_id' },
  },
  start_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  end_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM('PENDIENTE', 'EN_PROGRESO', 'FINALIZADA', 'CANCELADA'),
    defaultValue: 'PENDIENTE',
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    onUpdate: DataTypes.NOW,
  },
}, {
  tableName: 'routes',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

module.exports = Route;