const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DeliveryPhoto = sequelize.define('DeliveryPhoto', {
  photo_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  delivery_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  photo_url: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'delivery_photos',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  comment: 'Almacena fotos de entregas'
});

module.exports = DeliveryPhoto;