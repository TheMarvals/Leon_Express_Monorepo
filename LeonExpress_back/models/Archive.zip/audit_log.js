const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const AuditLog = sequelize.define('AuditLog', {
  log_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  user_id: {
    type: DataTypes.STRING(36)
  },
  action: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  target_table: {
    type: DataTypes.STRING(50)
  },
  target_id: {
    type: DataTypes.STRING(36)
  },
  details: {
    type: DataTypes.TEXT
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'audit_log',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  comment: 'Registra las acciones de auditoría'
});

module.exports = AuditLog;