const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Invoice = sequelize.define('Invoice', {
  invoice_id: {
    type: DataTypes.STRING(36),
    primaryKey: true,
    allowNull: false
  },
  client_id: {
    type: DataTypes.STRING(36),
    allowNull: false
  },
  invoice_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  due_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  total_amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00
  },
  status: {
    type: DataTypes.ENUM('PENDIENTE', 'PAGADA', 'VENCIDA', 'CANCELADA'),
    allowNull: false,
    defaultValue: 'PENDIENTE'
  },
  paid_at: {
    type: DataTypes.DATE,
    comment: 'Fecha y hora en que la factura fue completamente pagada'
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'invoices',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  comment: 'Gestiona las facturas a clientes'
});

module.exports = Invoice;